# Workshop Materials for the American Ornithological Society/Society of Canadian Ornithologist R Workshop
Home for the code and materials for Advanced R workshop being taught at the AOS/SCO Workshop in East Lansing, MI August 2017

Questions - aurielfournier@gmail.com @RallidaeRule
